# Janet Johnson — Data Analyst Portfolio

Built with TanStack Start, React 19, Tailwind v4.

## Run locally
```bash
bun install
bun dev
```
Open http://localhost:8080
