import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Janet Johnson — Data Analyst Portfolio" },
      { name: "description", content: "Janet Johnson is a Lagos-based data & business analyst turning complex datasets into clear, decisive insight with Power BI, SQL and Python." },
      { property: "og:title", content: "Janet Johnson — Data Analyst Portfolio" },
      { property: "og:description", content: "Power BI · SQL · Python — turning data into decisions." },
    ],
  }),
  component: Portfolio,
});

const NAV = [
  { href: "#work", label: "Work" },
  { href: "#about", label: "About" },
  { href: "#skills", label: "Skills" },
  { href: "#experience", label: "Experience" },
  { href: "#contact", label: "Contact" },
];

const PROJECTS = [
  {
    n: "01",
    title: "AdventureWorks Sales & Business Performance",
    tag: "Power BI · DAX · Python",
    summary:
      "A 3-page executive Power BI dashboard analysing $109.85M of sales across FY 2011–2014 — surfacing a margin paradox and a revenue mix recommendation worth millions.",
    metrics: [
      { k: "$109.85M", v: "sales analysed" },
      { k: "32K", v: "orders · 19K customers" },
      { k: "86%", v: "revenue from Bikes" },
      { k: "59.13%", v: "Accessories margin" },
    ],
    findings: [
      "Bikes drive 86% of revenue but only 8.77% margin — recommended mix shift toward Accessories.",
      "Uncovered 3 loss-making territories requiring strategy review.",
      "Flagged Road-250 Black selling below cost — immediate pricing action.",
    ],
  },
  {
    n: "02",
    title: "Online Retail RFM Customer Segmentation",
    tag: "Python · Pandas · Matplotlib",
    summary:
      "Cleaned a 1M+ row retail dataset and built an RFM segmentation model that turned anonymous transactions into a targeted retention playbook.",
    metrics: [
      { k: "1M+", v: "rows cleaned" },
      { k: "59,005", v: "invalid rows removed" },
      { k: "1,468", v: "Champion customers" },
      { k: "£8,081", v: "avg Champion spend" },
    ],
    findings: [
      "Identified 2,039 At-Risk / Lost customers for reactivation campaigns.",
      "Surfaced 118 high-spend low-frequency customers for personal outreach.",
      "Produced a 6-chart visual dashboard covering segments and regions.",
    ],
  },
  {
    n: "03",
    title: "Sales & Company Performance Analysis",
    tag: "Power BI · Excel · PostgreSQL",
    summary:
      "End-to-end pipeline from raw Excel to interactive Power BI — cleaning, EDA and KPI dashboards exposing ordering patterns, yearly trends and payment behaviour.",
    metrics: [
      { k: "100%", v: "data integrity post-clean" },
      { k: "3", v: "dashboard views" },
      { k: "KPI", v: "trend + product + payments" },
      { k: "SQL", v: "PostgreSQL pipeline" },
    ],
    findings: [
      "Standardised categorical fields and removed duplicates in Excel.",
      "EDA revealed customer ordering patterns and departmental distribution.",
      "Power BI dashboards tracking sales trends, product and payment KPIs.",
    ],
  },
];

const SKILLS = {
  Tools: ["Power BI", "DAX", "Microsoft Excel", "PostgreSQL", "Python", "Pandas", "Matplotlib", "Jupyter"],
  Analysis: ["Exploratory Data Analysis", "RFM Segmentation", "Revenue & Profit Analysis", "KPI Reporting", "Trend Analysis"],
  Delivery: ["Interactive Dashboards", "Executive Reporting", "Data Cleaning", "Data Querying", "Storytelling with Data"],
};

const EXPERIENCE = [
  {
    yr: "2025 — Present",
    role: "Teller",
    org: "Ecobank Nigeria Ltd",
    bullets: [
      "Process 150+ daily transactions with 100% till accuracy.",
      "KYC compliance and AML monitoring aligned to CBN standards.",
      "Manage Western Union / MoneyGram international remittance.",
    ],
  },
  {
    yr: "2021 — 2023",
    role: "Billing Officer / Customer Care",
    org: "Capital Gee Ventures",
    bullets: [
      "Reconciled client billing accounts monthly, reducing errors.",
      "Bank statement reconciliation and full accounts payable.",
      "Resolved discrepancies, improving database accuracy.",
    ],
  },
  {
    yr: "2020",
    role: "Accounts Intern",
    org: "Sona Plastics Limited",
    bullets: [
      "ERP tracking of inbound goods, storage and daily sales.",
      "Petty cash, ledgers and bookkeeping with zero unreconciled entries.",
      "Daily bank reconciliation and document control.",
    ],
  },
];

const CERTS = [
  { y: "2025 — Present", t: "Certificate in Data Analysis", o: "ALTSchool Africa" },
  { y: "2025", t: "Data Analyst Track Training", o: "Quantum Analytics NG" },
  { y: "2025", t: "Virtual Assistant & AI Starter Kit", o: "ALX Africa" },
  { y: "2023 — 2025", t: "HND, Accountancy", o: "Yaba College of Technology" },
  { y: "2018 — 2021", t: "OND, Accountancy", o: "Yaba College of Technology" },
];

function Portfolio() {
  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <Nav />
      <Hero />
      <Marquee />
      <Work />
      <About />
      <Skills />
      <Experience />
      <Certs />
      <Contact />
      <Footer />
    </div>
  );
}

function Nav() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-background/60 border-b border-border/50">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2 font-display text-xl">
          <span className="gradient-text">Janet</span>
          <span className="text-muted-foreground">Johnson</span>
        </a>
        <nav className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
          {NAV.map((n) => (
            <a key={n.href} href={n.href} className="hover:text-foreground transition-colors">
              {n.label}
            </a>
          ))}
        </nav>
        <a
          href="#contact"
          className="text-sm font-medium px-4 py-2 rounded-full border border-gold/40 text-gold hover:bg-gold hover:text-primary-foreground transition-colors"
        >
          Let's talk
        </a>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section id="top" className="relative pt-40 pb-24 px-6 lg:px-10">
      <div className="absolute inset-0 ring-grid opacity-60 pointer-events-none" />
      <div className="absolute top-32 right-10 w-[480px] h-[480px] rounded-full bg-gold/10 blur-[120px] pointer-events-none" />
      <div className="relative max-w-7xl mx-auto">
        <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-[0.2em] text-muted-foreground mb-8 fade-up">
          <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />
          Available for Data & Business Analyst roles · Lagos, NG
        </div>
        <h1 className="font-display text-[clamp(3rem,9vw,9rem)] leading-[0.95] tracking-tighter fade-up">
          Turning <em className="gradient-text">messy data</em><br />
          into <em className="italic font-display">decisions</em> the<br />
          business can act on.
        </h1>
        <div className="mt-12 grid md:grid-cols-3 gap-10 items-end">
          <p className="md:col-span-2 text-lg md:text-xl text-muted-foreground max-w-2xl leading-relaxed fade-up">
            I'm <span className="text-foreground">Janet Johnson</span>, a data & business analyst with a finance backbone.
            I clean, model and visualise data in Power BI, SQL and Python — then translate it into the one slide a CFO needs.
          </p>
          <div className="flex flex-col gap-3 fade-up">
            <a href="#work" className="group flex items-center justify-between px-5 py-4 rounded-lg bg-gold text-primary-foreground font-medium hover:glow-gold transition-shadow">
              View selected work
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </a>
            <a href="mailto:Johnsonjanet6117@gmail.com" className="flex items-center justify-between px-5 py-4 rounded-lg border border-border hover:border-gold/60 transition-colors">
              Email me
              <span className="text-muted-foreground">↗</span>
            </a>
          </div>
        </div>

        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6 fade-up">
          {[
            { k: "$109.85M", v: "Sales analysed" },
            { k: "1M+", v: "Rows cleaned" },
            { k: "3", v: "Featured projects" },
            { k: "5+", v: "Years in finance" },
          ].map((s) => (
            <div key={s.v} className="border-t border-border pt-4">
              <div className="font-display text-4xl md:text-5xl gradient-text">{s.k}</div>
              <div className="mt-2 text-sm text-muted-foreground">{s.v}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Marquee() {
  const items = ["Power BI", "SQL", "Python", "DAX", "Pandas", "Excel", "PostgreSQL", "Matplotlib", "RFM", "KPI Reporting"];
  return (
    <div className="relative border-y border-border py-6 overflow-hidden bg-card/40">
      <div className="flex marquee whitespace-nowrap gap-12 font-display text-3xl md:text-5xl">
        {[...items, ...items, ...items].map((t, i) => (
          <span key={i} className="flex items-center gap-12 text-muted-foreground">
            {t}
            <span className="text-gold">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function SectionLabel({ n, label }: { n: string; label: string }) {
  return (
    <div className="flex items-baseline gap-4 mb-12">
      <span className="font-mono text-xs text-gold">{n}</span>
      <span className="h-px flex-1 bg-border" />
      <span className="font-mono text-xs uppercase tracking-[0.25em] text-muted-foreground">{label}</span>
    </div>
  );
}

function Work() {
  return (
    <section id="work" className="px-6 lg:px-10 py-32 max-w-7xl mx-auto">
      <SectionLabel n="01 /" label="Selected Work" />
      <h2 className="font-display text-5xl md:text-7xl tracking-tighter max-w-3xl mb-20">
        Projects where data <em className="gradient-text">earned its keep</em>.
      </h2>
      <div className="space-y-24">
        {PROJECTS.map((p, i) => (
          <article key={p.n} className="grid lg:grid-cols-12 gap-8 lg:gap-12 group">
            <div className="lg:col-span-4">
              <div className="sticky top-24">
                <div className="font-mono text-sm text-gold mb-4">{p.n}</div>
                <h3 className="font-display text-3xl md:text-4xl leading-tight mb-4">{p.title}</h3>
                <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{p.tag}</div>
              </div>
            </div>
            <div className="lg:col-span-8">
              <div className="rounded-2xl border border-border bg-card p-8 md:p-10 hover:border-gold/40 transition-colors">
                <p className="text-lg text-muted-foreground leading-relaxed mb-8">{p.summary}</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-10 pb-10 border-b border-border">
                  {p.metrics.map((m) => (
                    <div key={m.v}>
                      <div className="font-display text-3xl gradient-text">{m.k}</div>
                      <div className="text-xs text-muted-foreground mt-1">{m.v}</div>
                    </div>
                  ))}
                </div>
                <ul className="space-y-4">
                  {p.findings.map((f) => (
                    <li key={f} className="flex gap-4 text-foreground/90">
                      <span className="text-gold mt-1.5 shrink-0">●</span>
                      <span className="leading-relaxed">{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="px-6 lg:px-10 py-32 max-w-7xl mx-auto">
      <SectionLabel n="02 /" label="About" />
      <div className="grid lg:grid-cols-12 gap-12">
        <div className="lg:col-span-7">
          <h2 className="font-display text-4xl md:text-6xl tracking-tighter leading-[1.05] mb-10">
            I read a P&L before I learned to read a pivot table — and that order matters.
          </h2>
          <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
            <p>
              I trained as an accountant at Yaba College of Technology (OND, then HND) and now serve customers daily as a teller at <span className="text-foreground">Ecobank Nigeria</span> — 150+ transactions a day, 100% till accuracy, KYC and AML in line with CBN.
            </p>
            <p>
              Finance taught me what a number is supposed to cost a business when it's wrong. Data analysis taught me how to find those numbers before they do damage.
            </p>
            <p>
              Today I work in Power BI, SQL and Python — building dashboards leaders can actually use, and writing the one paragraph of context that turns a chart into a decision.
            </p>
          </div>
        </div>
        <div className="lg:col-span-5">
          <div className="rounded-2xl border border-border bg-card p-8 sticky top-24">
            <div className="font-mono text-xs uppercase tracking-widest text-gold mb-6">At a glance</div>
            <dl className="space-y-5">
              {[
                ["Based in", "Lagos, Nigeria"],
                ["Currently", "Teller @ Ecobank · Analyst in training"],
                ["Studying", "Certificate in Data Analysis, ALTSchool Africa"],
                ["Open to", "Junior Data / Business Analyst roles, remote-friendly"],
                ["Stack", "Power BI · DAX · SQL · Python · Excel"],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-6 pb-5 border-b border-border last:border-0 last:pb-0">
                  <dt className="text-sm text-muted-foreground shrink-0">{k}</dt>
                  <dd className="text-sm text-right text-foreground">{v}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </div>
    </section>
  );
}

function Skills() {
  return (
    <section id="skills" className="px-6 lg:px-10 py-32 max-w-7xl mx-auto">
      <SectionLabel n="03 /" label="Capabilities" />
      <div className="grid md:grid-cols-3 gap-6">
        {Object.entries(SKILLS).map(([group, items], i) => (
          <div key={group} className="rounded-2xl border border-border bg-card p-8 hover:border-gold/40 transition-colors">
            <div className="flex items-center gap-3 mb-6">
              <span className="font-mono text-xs text-gold">0{i + 1}</span>
              <h3 className="font-display text-2xl">{group}</h3>
            </div>
            <ul className="flex flex-wrap gap-2">
              {items.map((it) => (
                <li key={it} className="text-sm px-3 py-1.5 rounded-full border border-border text-muted-foreground hover:text-foreground hover:border-gold/40 transition-colors">
                  {it}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}

function Experience() {
  return (
    <section id="experience" className="px-6 lg:px-10 py-32 max-w-7xl mx-auto">
      <SectionLabel n="04 /" label="Experience" />
      <div className="space-y-px">
        {EXPERIENCE.map((e) => (
          <details key={e.role} className="group border-t border-border last:border-b">
            <summary className="cursor-pointer py-8 grid grid-cols-12 gap-6 items-baseline hover:text-gold transition-colors list-none">
              <span className="col-span-12 md:col-span-2 font-mono text-sm text-muted-foreground">{e.yr}</span>
              <span className="col-span-12 md:col-span-5 font-display text-2xl md:text-3xl">{e.role}</span>
              <span className="col-span-12 md:col-span-4 text-muted-foreground">{e.org}</span>
              <span className="col-span-12 md:col-span-1 text-right text-gold text-2xl group-open:rotate-45 transition-transform">+</span>
            </summary>
            <ul className="pb-8 grid md:grid-cols-12 gap-6">
              <div className="md:col-start-3 md:col-span-9 space-y-3">
                {e.bullets.map((b) => (
                  <li key={b} className="flex gap-3 text-muted-foreground">
                    <span className="text-gold mt-1.5">—</span>
                    <span>{b}</span>
                  </li>
                ))}
              </div>
            </ul>
          </details>
        ))}
      </div>
    </section>
  );
}

function Certs() {
  return (
    <section className="px-6 lg:px-10 py-32 max-w-7xl mx-auto">
      <SectionLabel n="05 /" label="Education & Certifications" />
      <div className="grid md:grid-cols-2 gap-4">
        {CERTS.map((c) => (
          <div key={c.t} className="flex items-start gap-6 p-6 rounded-xl border border-border bg-card/60 hover:bg-card transition-colors">
            <div className="font-mono text-xs text-gold pt-1 shrink-0 w-28">{c.y}</div>
            <div>
              <div className="font-display text-xl leading-tight">{c.t}</div>
              <div className="text-sm text-muted-foreground mt-1">{c.o}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="relative px-6 lg:px-10 py-40 overflow-hidden">
      <div className="absolute inset-0 ring-grid opacity-40" />
      <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-gold/15 blur-[140px]" />
      <div className="relative max-w-5xl mx-auto text-center">
        <SectionLabel n="06 /" label="Get in touch" />
        <h2 className="font-display text-5xl md:text-8xl tracking-tighter leading-[0.95] mb-10">
          Have a dataset that's <em className="gradient-text">whispering something</em>?
          <br />Let's listen together.
        </h2>
        <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-12">
          I'm available for junior data analyst, business analyst and BI roles — full-time, contract or remote.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4">
          <a href="mailto:Johnsonjanet6117@gmail.com" className="px-7 py-4 rounded-full bg-gold text-primary-foreground font-medium hover:glow-gold transition-shadow">
            Johnsonjanet6117@gmail.com
          </a>
          <a href="tel:+2347012604645" className="px-7 py-4 rounded-full border border-border hover:border-gold/60 transition-colors">
            +234 701-260-4645
          </a>
          <a href="https://linkedin.com/in/janet-johnson-oj" target="_blank" rel="noreferrer" className="px-7 py-4 rounded-full border border-border hover:border-gold/60 transition-colors">
            LinkedIn ↗
          </a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border px-6 lg:px-10 py-10">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-4 items-center justify-between text-sm text-muted-foreground">
        <div>© {new Date().getFullYear()} Janet Johnson · Lagos, Nigeria</div>
        <div className="font-mono text-xs uppercase tracking-widest">Designed with intent. Built with data.</div>
      </div>
    </footer>
  );
}
