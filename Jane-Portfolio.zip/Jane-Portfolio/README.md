# Janet Johnson — Data Analyst Portfolio

Built with TanStack Start + React 19 + Vite 7 + Tailwind CSS v4.

## Structure
- `src/routes/` — file-based routes (`__root.tsx`, `index.tsx`)
- `src/components/ui/` — shadcn UI components
- `src/styles/` — global CSS (Tailwind v4 + design tokens)
- `src/assets/` — static assets imported by code
- `public/images/` — public static images

## Run
```
bun install
bun dev
```
