// TanStack Start handles SSR entry automatically via its Vite plugin.
// This file is provided for reference / parity with the requested folder layout.
// The real bootstrap lives in src/router.tsx and src/routes/__root.tsx.
import { getRouter } from "./router";
export default getRouter;
